import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { VoiceVisualizer } from "./voice-visualizer";
import { Phone, Mic, MicOff, MoreVertical, Globe, Bot } from "lucide-react";
import { useState, useEffect } from "react";

export function ActiveCallPanel() {
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [isAiActive, setIsAiActive] = useState(true);

  useEffect(() => {
    const timer = setInterval(() => setDuration((prev) => prev + 1), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <Card className="glass-panel p-6 flex flex-col gap-6 relative overflow-hidden">
      {/* Background Gradient */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2 pointer-events-none" />

      {/* Header */}
      <div className="flex justify-between items-start z-10">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 rounded-full bg-gradient-to-br from-primary to-blue-600 flex items-center justify-center shadow-lg shadow-primary/20">
            <span className="font-display font-bold text-xl text-black">JD</span>
          </div>
          <div>
            <h2 className="font-display text-2xl font-semibold">John Doe</h2>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <span className="flex h-2 w-2 rounded-full bg-red-500 animate-pulse" />
              <span>+1 (555) 0123-4567</span>
              <span className="w-1 h-1 rounded-full bg-muted-foreground" />
              <span className="font-mono text-primary">{formatTime(duration)}</span>
            </div>
          </div>
        </div>
        
        <div className="flex gap-2">
           <Button variant="outline" size="icon" className="rounded-full border-primary/20 hover:bg-primary/10">
             <Globe className="h-4 w-4 text-primary" />
           </Button>
           <Button variant="ghost" size="icon" className="rounded-full">
             <MoreVertical className="h-4 w-4" />
           </Button>
        </div>
      </div>

      {/* Visualizers */}
      <div className="space-y-6 py-4 z-10">
        <div className="space-y-2">
          <div className="flex justify-between text-xs uppercase tracking-wider font-mono text-muted-foreground">
            <span>Incoming Audio (Spanish)</span>
            <span className="text-primary">Live Translating...</span>
          </div>
          <VoiceVisualizer isActive={true} color="bg-primary" />
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-xs uppercase tracking-wider font-mono text-muted-foreground">
            <span>Outgoing Audio (AI Voice)</span>
            <span className="text-accent">Synthesizing...</span>
          </div>
          <VoiceVisualizer isActive={isAiActive} color="bg-accent" />
        </div>
      </div>

      {/* Controls */}
      <div className="grid grid-cols-4 gap-4 mt-auto z-10">
        <Button 
          variant={isMuted ? "destructive" : "secondary"} 
          className="h-14 rounded-2xl flex flex-col gap-1"
          onClick={() => setIsMuted(!isMuted)}
        >
          {isMuted ? <MicOff className="h-5 w-5" /> : <Mic className="h-5 w-5" />}
          <span className="text-[10px] uppercase font-bold">{isMuted ? "Unmute" : "Mute"}</span>
        </Button>
        
        <Button 
          variant={isAiActive ? "default" : "secondary"} 
          className={`h-14 rounded-2xl flex flex-col gap-1 ${isAiActive ? "bg-accent hover:bg-accent/90 text-white" : ""}`}
          onClick={() => setIsAiActive(!isAiActive)}
        >
          <Bot className="h-5 w-5" />
          <span className="text-[10px] uppercase font-bold">AI Assist</span>
        </Button>

        <Button variant="secondary" className="h-14 rounded-2xl flex flex-col gap-1">
          <Globe className="h-5 w-5" />
          <span className="text-[10px] uppercase font-bold">Lang</span>
        </Button>

        <Button variant="destructive" className="h-14 rounded-2xl flex flex-col gap-1 bg-red-600 hover:bg-red-700">
          <Phone className="h-5 w-5 rotate-[135deg]" />
          <span className="text-[10px] uppercase font-bold">End</span>
        </Button>
      </div>
    </Card>
  );
}
