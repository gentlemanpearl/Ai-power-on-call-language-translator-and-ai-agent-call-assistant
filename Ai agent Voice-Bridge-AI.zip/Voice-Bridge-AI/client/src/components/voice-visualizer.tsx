import { motion } from "framer-motion";
import { useEffect, useState } from "react";

interface VoiceVisualizerProps {
  isActive: boolean;
  color?: string;
}

export function VoiceVisualizer({ isActive, color = "bg-primary" }: VoiceVisualizerProps) {
  // Create an array of 20 bars
  const bars = Array.from({ length: 20 });

  return (
    <div className="flex items-center justify-center gap-1 h-16 w-full">
      {bars.map((_, i) => (
        <Bar key={i} isActive={isActive} color={color} index={i} />
      ))}
    </div>
  );
}

function Bar({ isActive, color, index }: { isActive: boolean; color: string; index: number }) {
  const [height, setHeight] = useState(10);

  useEffect(() => {
    if (!isActive) {
      setHeight(4);
      return;
    }

    const interval = setInterval(() => {
      // Random height between 10% and 100%
      setHeight(Math.random() * 90 + 10);
    }, 100);

    return () => clearInterval(interval);
  }, [isActive]);

  return (
    <motion.div
      className={`w-1.5 rounded-full ${color}`}
      animate={{ height: `${height}%` }}
      transition={{ type: "spring", stiffness: 300, damping: 20 }}
      style={{ opacity: isActive ? 1 : 0.3 }}
    />
  );
}
