import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useRef } from "react";

export interface Message {
  id: string;
  sender: "caller" | "agent" | "ai";
  originalText: string;
  translatedText?: string;
  language: string;
  timestamp: string;
}

interface LiveTranscriptProps {
  messages: Message[];
}

export function LiveTranscript({ messages }: LiveTranscriptProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      const scrollContainer = scrollRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  }, [messages]);

  return (
    <div className="h-full flex flex-col glass-panel rounded-xl overflow-hidden border border-border/50">
      <div className="p-4 border-b border-border/50 flex justify-between items-center bg-card/40">
        <div className="flex items-center gap-2">
          <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
          <h3 className="font-display font-semibold text-lg tracking-wide">Live Transcript</h3>
        </div>
        <Badge variant="outline" className="border-primary/30 text-primary font-mono text-xs">
          EN ⇄ ES
        </Badge>
      </div>

      <ScrollArea className="flex-1 p-4" ref={scrollRef}>
        <div className="space-y-4">
          <AnimatePresence initial={false}>
            {messages.map((msg) => (
              <motion.div
                key={msg.id}
                initial={{ opacity: 0, y: 20, scale: 0.95 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ duration: 0.3 }}
                className={`flex flex-col ${
                  msg.sender === "caller" ? "items-start" : "items-end"
                }`}
              >
                <div
                  className={`max-w-[80%] rounded-2xl p-4 ${
                    msg.sender === "caller"
                      ? "bg-secondary/50 rounded-tl-sm border-l-2 border-l-secondary"
                      : msg.sender === "ai" 
                        ? "bg-primary/10 rounded-tr-sm border-r-2 border-r-primary"
                        : "bg-accent/10 rounded-tr-sm border-r-2 border-r-accent"
                  }`}
                >
                  <div className="flex justify-between items-center mb-1 gap-4">
                    <span className="text-xs font-mono uppercase opacity-70">
                      {msg.sender === "caller" ? "Caller (ES)" : msg.sender === "ai" ? "AI Assistant" : "Agent (EN)"}
                    </span>
                    <span className="text-xs font-mono opacity-50">{msg.timestamp}</span>
                  </div>
                  
                  {msg.translatedText && (
                    <p className="text-sm font-medium text-foreground mb-1 leading-relaxed">
                      {msg.translatedText}
                    </p>
                  )}
                  
                  <p className={`text-xs ${msg.translatedText ? "text-muted-foreground italic" : "text-foreground"}`}>
                    {msg.originalText}
                  </p>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      </ScrollArea>
    </div>
  );
}
