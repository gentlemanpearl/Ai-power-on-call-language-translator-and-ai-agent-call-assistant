import { useState, useEffect } from "react";
import { ActiveCallPanel } from "@/components/active-call-panel";
import { LiveTranscript, Message } from "@/components/live-transcript";
import { Card } from "@/components/ui/card";
import { Activity, Signal, Wifi, Battery, Settings, Bell, Search, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import generatedImage from '@assets/generated_images/abstract_digital_sound_waves_visualization,_glowing_cyan_and_blue_lines_on_black_background.png';

export default function Dashboard() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "caller",
      originalText: "Hola, buenos días. Estoy llamando porque tengo un problema con mi factura.",
      translatedText: "Hello, good morning. I am calling because I have a problem with my bill.",
      language: "es",
      timestamp: "10:23:45"
    },
    {
      id: "2",
      sender: "ai",
      originalText: "I understand. I can help you with that. Can you please confirm your account number?",
      translatedText: "Entiendo. Puedo ayudarte con eso. ¿Podrías confirmar tu número de cuenta?",
      language: "en",
      timestamp: "10:23:50"
    }
  ]);

  // Simulate incoming messages
  useEffect(() => {
    const scenarios = [
      {
        sender: "caller",
        originalText: "Sí, es el 555-987-654.",
        translatedText: "Yes, it is 555-987-654.",
        delay: 3000
      },
      {
        sender: "ai",
        originalText: "Thank you. I see your last payment was processed yesterday.",
        translatedText: "Gracias. Veo que su último pago fue procesado ayer.",
        delay: 6000
      },
      {
        sender: "caller",
        originalText: "Pero me cobraron dos veces.",
        translatedText: "But I was charged twice.",
        delay: 9000
      },
      {
        sender: "ai",
        originalText: "I apologize for the inconvenience. Let me check the transaction details.",
        translatedText: "Me disculpo por el inconveniente. Déjame revisar los detalles de la transacción.",
        delay: 12000
      }
    ];

    let timeouts: NodeJS.Timeout[] = [];

    scenarios.forEach((scenario, index) => {
      const timeout = setTimeout(() => {
        setMessages(prev => [...prev, {
          id: Date.now().toString(),
          sender: scenario.sender as any,
          originalText: scenario.originalText,
          translatedText: scenario.translatedText,
          language: scenario.sender === "caller" ? "es" : "en",
          timestamp: new Date().toLocaleTimeString('en-US', { hour12: false })
        }]);
      }, scenario.delay);
      timeouts.push(timeout);
    });

    return () => timeouts.forEach(clearTimeout);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden relative font-sans">
      {/* Background Image Layer */}
      <div 
        className="absolute inset-0 z-0 opacity-20 pointer-events-none"
        style={{
          backgroundImage: `url(${generatedImage})`,
          backgroundSize: 'cover',
          backgroundPosition: 'center',
          mixBlendMode: 'screen'
        }}
      />
      
      {/* Top Navigation */}
      <header className="h-16 border-b border-border/40 bg-background/50 backdrop-blur-md flex items-center justify-between px-6 sticky top-0 z-50">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-primary flex items-center justify-center">
              <Activity className="h-5 w-5 text-black" />
            </div>
            <h1 className="font-display font-bold text-xl tracking-wider hidden md:block">
              VOX<span className="text-primary">LINK</span> AI
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-4 bg-card/30 px-4 py-2 rounded-full border border-white/5 w-1/3">
          <Search className="h-4 w-4 text-muted-foreground" />
          <Input 
            placeholder="Search logs, customers, or calls..." 
            className="border-none bg-transparent h-auto p-0 focus-visible:ring-0 placeholder:text-muted-foreground/50"
          />
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 rounded-full bg-green-500/10 border border-green-500/20">
            <div className="h-2 w-2 rounded-full bg-green-500 animate-pulse" />
            <span className="text-xs font-medium text-green-500">System Operational</span>
          </div>
          <Button variant="ghost" size="icon" className="text-muted-foreground hover:text-primary">
            <Bell className="h-5 w-5" />
          </Button>
          <div className="h-8 w-8 rounded-full bg-secondary border border-white/10" />
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto p-6 grid grid-cols-1 lg:grid-cols-12 gap-6 h-[calc(100vh-4rem)]">
        
        {/* Left Column: Active Call & Stats */}
        <div className="lg:col-span-4 flex flex-col gap-6">
          <ActiveCallPanel />
          
          <div className="grid grid-cols-2 gap-4">
            <Card className="glass-panel p-4 flex flex-col gap-2">
              <span className="text-xs text-muted-foreground font-mono uppercase">Sentiment</span>
              <div className="flex items-end gap-2">
                <span className="text-2xl font-display font-bold text-green-400">Positive</span>
                <span className="text-xs mb-1 text-green-400/70">84%</span>
              </div>
              <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
                <div className="h-full w-[84%] bg-green-400" />
              </div>
            </Card>
            
            <Card className="glass-panel p-4 flex flex-col gap-2">
              <span className="text-xs text-muted-foreground font-mono uppercase">Translation Delay</span>
              <div className="flex items-end gap-2">
                <span className="text-2xl font-display font-bold text-primary">0.2s</span>
                <span className="text-xs mb-1 text-primary/70">Ultra-Low</span>
              </div>
              <div className="h-1 w-full bg-secondary rounded-full overflow-hidden">
                <div className="h-full w-[95%] bg-primary" />
              </div>
            </Card>
          </div>

          <Card className="glass-panel p-4 flex-1">
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-display font-semibold">System Metrics</h3>
              <Settings className="h-4 w-4 text-muted-foreground" />
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Signal className="h-4 w-4 text-primary" />
                  <span>Signal Strength</span>
                </div>
                <span className="font-mono text-primary">Excellent</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Wifi className="h-4 w-4 text-accent" />
                  <span>Bandwidth</span>
                </div>
                <span className="font-mono text-accent">1.2 Gbps</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <Battery className="h-4 w-4 text-green-400" />
                  <span>Server Load</span>
                </div>
                <span className="font-mono text-green-400">12%</span>
              </div>
            </div>
          </Card>
        </div>

        {/* Right Column: Transcript */}
        <div className="lg:col-span-8 h-full pb-6">
          <LiveTranscript messages={messages} />
        </div>
      </main>
    </div>
  );
}
